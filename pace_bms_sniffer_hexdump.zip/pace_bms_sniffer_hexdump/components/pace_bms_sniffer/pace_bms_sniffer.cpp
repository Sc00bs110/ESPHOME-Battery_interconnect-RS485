#include "pace_bms_sniffer.h"
#include "esphome/core/log.h"
#include <iomanip>
#include <sstream>

namespace esphome {
namespace pace_bms_sniffer {

static const char *const TAG = "pace_bms_sniffer";

void PaceBMSSniffer::setup() {
  ESP_LOGI(TAG, "========================================");
  ESP_LOGI(TAG, "PACE BMS Sniffer - HEX DUMP MODE");
  ESP_LOGI(TAG, "========================================");
  ESP_LOGI(TAG, "Protocol: Version 25");
  ESP_LOGI(TAG, "Mode: PASSIVE LISTENING (RX ONLY)");
  ESP_LOGI(TAG, "Monitoring: 8 battery packs (addresses 0x01-0x08)");
  ESP_LOGI(TAG, "========================================");
}

void PaceBMSSniffer::loop() {
  // Read available data from UART
  while (available()) {
    uint8_t byte;
    read_byte(&byte);
    
    // Look for frame start
    if (byte == FRAME_START) {
      rx_buffer_.clear();
      rx_buffer_.push_back(byte);
    }
    else if (!rx_buffer_.empty()) {
      rx_buffer_.push_back(byte);
      
      // Check for frame end
      if (byte == FRAME_END) {
        if (rx_buffer_.size() > 10) {  // Minimum valid frame size
          print_hex_dump(rx_buffer_);
          process_frame(rx_buffer_);
        }
        rx_buffer_.clear();
      }
      
      // Prevent buffer overflow
      if (rx_buffer_.size() > MAX_FRAME_SIZE) {
        ESP_LOGW(TAG, "Frame too large (%d bytes), discarding", rx_buffer_.size());
        rx_buffer_.clear();
      }
    }
  }
}

void PaceBMSSniffer::dump_config() {
  ESP_LOGCONFIG(TAG, "PACE BMS Sniffer:");
  ESP_LOGCONFIG(TAG, "  Protocol: Version 25");
  ESP_LOGCONFIG(TAG, "  Batteries: 8 (0x01-0x08)");
  ESP_LOGCONFIG(TAG, "  Mode: Passive (RX only)");
  ESP_LOGCONFIG(TAG, "  Hex Dump: ENABLED");
}

void PaceBMSSniffer::print_hex_dump(const std::vector<uint8_t> &frame) {
  if (frame.size() < 7) {
    return;  // Too short to be valid
  }
  
  // Extract basic frame info
  uint8_t protocol_v1 = frame[1];
  uint8_t protocol_v2 = frame[2];
  uint8_t addr_h = frame[3];
  uint8_t addr_l = frame[4];
  uint8_t cmd_h = frame[5];
  uint8_t cmd_l = frame[6];
  
  // Convert to actual values
  uint8_t addr = (hex_char_to_byte(addr_h) << 4) | hex_char_to_byte(addr_l);
  uint8_t cmd = (hex_char_to_byte(cmd_h) << 4) | hex_char_to_byte(cmd_l);
  
  // Create hex string for entire frame
  std::string hex_str;
  std::string ascii_str;
  
  for (size_t i = 0; i < frame.size(); i++) {
    char buf[4];
    snprintf(buf, sizeof(buf), "%02X ", frame[i]);
    hex_str += buf;
    
    // ASCII representation
    if (frame[i] >= 0x20 && frame[i] <= 0x7E) {
      ascii_str += (char)frame[i];
    } else {
      ascii_str += '.';
    }
  }
  
  // Determine if this is a command or response
  bool is_response = (frame.size() > 10 && frame[7] == '0' && frame[8] == '0');
  const char *direction = is_response ? "RESP" : "CMD ";
  
  // Log the frame with clear formatting
  ESP_LOGI(TAG, "========================================");
  ESP_LOGI(TAG, "[%s] Pack: 0x%02X | Cmd: 0x%02X | Len: %d bytes", 
           direction, addr, cmd, frame.size());
  ESP_LOGI(TAG, "----------------------------------------");
  ESP_LOGI(TAG, "HEX: %s", hex_str.c_str());
  ESP_LOGI(TAG, "ASCII: %s", ascii_str.c_str());
  ESP_LOGI(TAG, "========================================");
}

uint8_t PaceBMSSniffer::hex_char_to_byte(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return 0;
}

uint16_t PaceBMSSniffer::parse_hex_word(const uint8_t *data) {
  // Parse 4 ASCII hex characters to uint16_t
  return (hex_char_to_byte(data[0]) << 12) |
         (hex_char_to_byte(data[1]) << 8) |
         (hex_char_to_byte(data[2]) << 4) |
         (hex_char_to_byte(data[3]));
}

uint32_t PaceBMSSniffer::parse_hex_dword(const uint8_t *data) {
  // Parse 8 ASCII hex characters to uint32_t
  return (static_cast<uint32_t>(parse_hex_word(data)) << 16) |
         parse_hex_word(data + 4);
}

void PaceBMSSniffer::process_frame(const std::vector<uint8_t> &frame) {
  // Frame format: ~25[ADDR][CMD][DATA][CHECKSUM]\r
  
  if (frame.size() < 15) {
    return;  // Too short
  }
  
  // Check protocol version
  if (frame[1] != '2' || frame[2] != '5') {
    ESP_LOGW(TAG, "Not protocol v25 (got: %c%c)", frame[1], frame[2]);
    return;
  }
  
  // Extract address (2 ASCII chars)
  uint8_t addr = (hex_char_to_byte(frame[3]) << 4) | hex_char_to_byte(frame[4]);
  
  if (addr < 1 || addr > 8) {
    ESP_LOGD(TAG, "Address 0x%02X outside expected range (1-8)", addr);
    return;
  }
  
  // Extract command (2 ASCII chars)
  uint8_t cmd = (hex_char_to_byte(frame[5]) << 4) | hex_char_to_byte(frame[6]);
  
  ESP_LOGD(TAG, "Processing: Pack %d, Command 0x%02X", addr, cmd);
  
  // Command 0x46 = Read analog data
  if (cmd == 0x46) {
    // Check if this is a response (contains "00" after command)
    if (frame.size() > 10 && frame[7] == '0' && frame[8] == '0') {
      // This is a response with data
      decode_analog_data(frame, addr);
    }
  }
}

bool PaceBMSSniffer::decode_analog_data(const std::vector<uint8_t> &frame, uint8_t pack_addr) {
  // Frame: ~25[ADDR]4600[TYPE][DATA][CHECKSUM]\r
  
  if (frame.size() < 50) {
    ESP_LOGW(TAG, "Frame too short for analog data (%d bytes)", frame.size());
    return false;
  }
  
  uint8_t pack_idx = pack_addr - 1;
  if (pack_idx >= NUM_PACKS) {
    return false;
  }
  
  // Check response type (position 9-12: "1096" for full analog data)
  if (frame[9] != '1' || frame[10] != '0' || frame[11] != '9' || frame[12] != '6') {
    ESP_LOGD(TAG, "Not full analog data (type: %c%c%c%c)", 
             frame[9], frame[10], frame[11], frame[12]);
    return false;
  }
  
  ESP_LOGI(TAG, "┌─────────────────────────────────────────┐");
  ESP_LOGI(TAG, "│  DECODING PACK %d ANALOG DATA           │", pack_addr);
  ESP_LOGI(TAG, "└─────────────────────────────────────────┘");
  
  // Data starts at a specific position - need to analyze frame structure
  size_t pos = 21;  // Starting position (may need adjustment)
  
  if (frame.size() < pos + (NUM_CELLS * 4)) {
    ESP_LOGW(TAG, "Frame too short for cell voltages");
    return false;
  }
  
  // Parse 16 cell voltages (4 ASCII hex chars each = 2 bytes)
  ESP_LOGI(TAG, "Cell Voltages:");
  for (size_t i = 0; i < NUM_CELLS; i++) {
    uint16_t raw_mv = parse_hex_word(&frame[pos + (i * 4)]);
    pack_data_[pack_idx].cell_voltages[i] = raw_mv / 1000.0f;
    ESP_LOGI(TAG, "  Cell %2d: %d mV (%.3f V) [Hex: %c%c%c%c]", 
             i + 1, raw_mv, pack_data_[pack_idx].cell_voltages[i],
             frame[pos + (i * 4)], frame[pos + (i * 4) + 1],
             frame[pos + (i * 4) + 2], frame[pos + (i * 4) + 3]);
  }
  pos += NUM_CELLS * 4;
  
  // Parse temperatures
  ESP_LOGI(TAG, "Temperatures:");
  for (size_t i = 0; i < NUM_TEMPS && pos + 5 <= frame.size(); i++) {
    // Skip type/status byte
    pos++;
    if (pos + 4 > frame.size()) break;
    
    uint16_t raw_temp = parse_hex_word(&frame[pos]);
    pack_data_[pack_idx].temperatures[i] = raw_temp / 100.0f;
    ESP_LOGI(TAG, "  Temp %d: %d raw (%.1f °C) [Hex: %c%c%c%c]", 
             i + 1, raw_temp, pack_data_[pack_idx].temperatures[i],
             frame[pos], frame[pos + 1], frame[pos + 2], frame[pos + 3]);
    pos += 4;
  }
  
  // Try to find and parse pack voltage, current, SOC, etc.
  ESP_LOGI(TAG, "Pack Data (positions may need adjustment):");
  
  if (pos + 20 < frame.size()) {
    // Skip padding
    pos += 4;
    
    // Pack voltage
    if (pos + 4 <= frame.size()) {
      uint16_t raw_voltage = parse_hex_word(&frame[pos]);
      pack_data_[pack_idx].voltage = raw_voltage / 100.0f;
      ESP_LOGI(TAG, "  Voltage: %d raw (%.2f V) [Hex: %c%c%c%c] @ pos %d", 
               raw_voltage, pack_data_[pack_idx].voltage,
               frame[pos], frame[pos + 1], frame[pos + 2], frame[pos + 3], pos);
      pos += 4;
    }
    
    // More fields to decode...
    ESP_LOGI(TAG, "  Remaining data at pos %d: %d bytes", pos, frame.size() - pos);
    
    // Show next 40 bytes for analysis
    if (pos + 40 <= frame.size()) {
      std::string hex_preview;
      for (size_t i = 0; i < 40 && pos + i < frame.size(); i++) {
        char buf[4];
        snprintf(buf, sizeof(buf), "%c", frame[pos + i]);
        hex_preview += buf;
      }
      ESP_LOGI(TAG, "  Next 40 chars: %s", hex_preview.c_str());
    }
  }
  
  pack_data_[pack_idx].valid = true;
  pack_data_[pack_idx].last_update = millis();
  
  calculate_pack_stats(pack_idx);
  
  ESP_LOGI(TAG, "└─────────────────────────────────────────┘");
  
  return true;
}

void PaceBMSSniffer::calculate_pack_stats(uint8_t pack_idx) {
  if (pack_idx >= NUM_PACKS) return;
  
  auto &pack = pack_data_[pack_idx];
  
  pack.min_cell_v = pack.cell_voltages[0];
  pack.max_cell_v = pack.cell_voltages[0];
  float sum = 0;
  
  for (size_t i = 0; i < NUM_CELLS; i++) {
    if (pack.cell_voltages[i] < pack.min_cell_v) {
      pack.min_cell_v = pack.cell_voltages[i];
    }
    if (pack.cell_voltages[i] > pack.max_cell_v) {
      pack.max_cell_v = pack.cell_voltages[i];
    }
    sum += pack.cell_voltages[i];
  }
  
  pack.avg_cell_v = sum / NUM_CELLS;
  pack.delta_cell_v = pack.max_cell_v - pack.min_cell_v;
  
  ESP_LOGI(TAG, "Cell Statistics:");
  ESP_LOGI(TAG, "  Min: %.3f V", pack.min_cell_v);
  ESP_LOGI(TAG, "  Max: %.3f V", pack.max_cell_v);
  ESP_LOGI(TAG, "  Avg: %.3f V", pack.avg_cell_v);
  ESP_LOGI(TAG, "  Delta: %.3f V", pack.delta_cell_v);
  ESP_LOGI(TAG, "  Sum: %.2f V (Pack voltage should be ~%.1f V)", 
           sum, sum);
}

void PaceBMSSniffer::publish_pack_data(uint8_t pack_idx) {
  // Not publishing sensors yet - just logging for verification
  ESP_LOGD(TAG, "Pack %d data ready for publishing", pack_idx + 1);
}

}  // namespace pace_bms_sniffer
}  // namespace esphome
