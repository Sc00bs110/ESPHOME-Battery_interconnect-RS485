# PACE BMS Sniffer Project - Complete Package

## 📦 What's Included

This package contains everything you need for **Phase 1** of your PACE BMS integration project.

---

## 📄 Files Overview

| File | Purpose |
|------|---------|
| **QUICKSTART.md** | ⚡ Start here! Quick 3-step installation guide |
| **README.md** | 📖 Complete documentation with troubleshooting |
| **VERIFICATION_TEMPLATE.md** | 📋 Template for reporting your findings |
| **pace-bms-sniffer-hexdump.yaml** | ⚙️ Main ESPHome configuration file |
| **components/pace_bms_sniffer/** | 🔧 Custom component code (3 files) |

---

## 🎯 Project Goals

### Phase 1 (Current) - Verification
✅ Capture raw RS485 frames from battery daisy chain  
✅ Output hex dumps to verify data structure  
✅ Decode and validate cell voltages and temperatures  
✅ Identify correct byte positions for all parameters  
✅ Confirm parsing matches your actual battery values  

### Phase 2 (Next) - Integration
⬜ Create Home Assistant sensors for all 8 battery packs  
⬜ Implement proper data refresh rate limiting  
⬜ Add charge/discharge status indicators  
⬜ Add battery health monitoring  
⬜ Create dashboard cards for visualization  

---

## 🚀 Getting Started (Quick Path)

1. **Read QUICKSTART.md** - Follow the 3-step installation
2. **Wire your ESP32** - Connect to inter-battery RS485 (RX only!)
3. **Upload firmware** - Use ESPHome dashboard or CLI
4. **View logs** - Watch hex dumps appear
5. **Fill out VERIFICATION_TEMPLATE.md** - Compare decoded vs actual values
6. **Report back** - Share findings for Phase 2

---

## 📚 Documentation Guide

### For Quick Installation
→ **Read: QUICKSTART.md**
- 3-step setup process
- Wiring diagram
- How to view logs
- Quick troubleshooting

### For Detailed Information
→ **Read: README.md**
- Complete technical documentation
- Frame format details
- In-depth troubleshooting
- Background on PACE BMS protocol
- Phase 2 roadmap

### For Reporting Results
→ **Use: VERIFICATION_TEMPLATE.md**
- Structured template for findings
- Comparison tables
- Space for observations
- Checklist format

---

## 🔌 Hardware Requirements

- **ESP32 development board** (ESP32, ESP32-C3, ESP32-S2, or ESP32-S3)
- **RS485 to TTL module** (e.g., MAX485 based)
- **Connecting wires**
- **Access to battery inter-battery communication port** (RJ45 pins 7&8)

---

## ⚙️ Software Requirements

- **ESPHome** (installed via Home Assistant add-on or standalone)
- **Home Assistant** (optional but recommended)
- **Text editor** for viewing logs

---

## 🔒 Safety & Critical Notes

### ⚠️ PASSIVE MODE ONLY
- ESP32 will **NEVER transmit** on the RS485 bus
- Only the RX (receive) pin is connected
- Cannot interfere with battery operation
- Safe to run 24/7 while batteries are operating

### ⚠️ CORRECT PORT
- Connect to **INTER-BATTERY** ports (typically RJ45 pins 7&8)
- Do NOT use the user communication port (pins 1&2)
- This is where batteries talk to each other

### ⚠️ POLARITY
- A+ to A+, B- to B-
- Wrong polarity = no communication
- Won't damage anything, but won't work

---

## 📊 What You'll Learn

By the end of Phase 1, you'll have:

1. **Confirmed data structure** - Know exactly where each field is in the RS485 frames
2. **Verified parsing** - Cell voltages, temps, voltage, current, SOC all correct
3. **Frame examples** - Actual hex dumps from your system
4. **Confidence** - Ready to move to full sensor integration

---

## 🔄 Project Timeline

```
Phase 1: Verification (Current)        Phase 2: Integration (Next)
┌─────────────────────────┐           ┌──────────────────────────┐
│                         │           │                          │
│ 1. Install hex dump     │           │ 1. Create HA sensors     │
│    firmware             │           │                          │
│                         │──────────▶│ 2. Add rate limiting     │
│ 2. Capture frames       │           │                          │
│                         │           │ 3. Test all 8 packs      │
│ 3. Verify parsing       │           │                          │
│                         │           │ 4. Create dashboards     │
│ 4. Report findings      │           │                          │
│                         │           │ 5. Deploy final version  │
└─────────────────────────┘           └──────────────────────────┘
        YOU ARE HERE                      (Coming after verification)
```

---

## 📋 Pre-Flight Checklist

Before you start:

- [ ] ESP32 board is powered and accessible
- [ ] RS485 module is properly wired to ESP32
- [ ] You have access to battery inter-battery connection ports
- [ ] ESPHome is installed and working
- [ ] WiFi credentials are ready
- [ ] You can access ESPHome logs
- [ ] You have your current battery values for comparison

---

## 🎓 Learning Resources

### PACE BMS Protocol
- Protocol Version: 25
- Frame Format: ~25[ADDR][CMD][DATA][CHECKSUM]\r
- Baud Rate: 9600
- Data Format: ASCII hex characters

### Key Concepts
- **Inter-battery communication**: Master battery polls slaves
- **Protocol 25**: Modern PACE BMS standard (used by BSL, SOK, EG4, etc.)
- **Passive sniffing**: Read-only monitoring without interfering
- **Hex dump**: Raw byte view for debugging and verification

---

## 🆘 Getting Help

### Quick Issues
1. Check QUICKSTART.md troubleshooting section
2. Check README.md detailed troubleshooting

### Still Stuck?
1. Capture full logs (30+ seconds)
2. Fill out VERIFICATION_TEMPLATE.md
3. Take photos of wiring
4. Share battery model details
5. Contact for support

---

## ✅ Success Criteria

You'll know Phase 1 is complete when:

- ✅ Hex dumps appear in logs
- ✅ Cell voltages match actual values (±0.001V)
- ✅ Temperatures are reasonable (not 500°C!)
- ✅ Pack voltage is correct (~52V for 16S)
- ✅ You can see data from all connected batteries
- ✅ Verification template is filled out

---

## 🚀 Ready to Begin?

1. **Start with QUICKSTART.md**
2. **Install and run**
3. **Observe hex dumps**
4. **Compare with actual values**
5. **Report findings**
6. **Move to Phase 2!**

---

## 📞 Support Information

This is Phase 1 of a two-phase project:
- Phase 1: Verify we can read and parse the data correctly
- Phase 2: Create full Home Assistant integration with sensors

**Remember**: We're not creating sensors yet in this phase. This is purely about verification and understanding the data format!

---

## 🎉 Let's Do This!

You have everything you need to get started. Follow the QUICKSTART guide and you'll be seeing battery data in minutes!

**Good luck!** 🔋⚡🚀
