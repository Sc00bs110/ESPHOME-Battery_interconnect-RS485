# QUICK START GUIDE - PACE BMS Sniffer Hex Dump Mode

## 📦 Files Included

```
pace_bms_sniffer_hexdump/
├── README.md                            ← Full documentation
├── pace-bms-sniffer-hexdump.yaml       ← Main ESPHome config
└── components/
    └── pace_bms_sniffer/
        ├── __init__.py                  ← Component registration
        ├── pace_bms_sniffer.h           ← Header file
        └── pace_bms_sniffer.cpp         ← Implementation with hex dump
```

---

## ⚡ Quick Installation (3 steps)

### Step 1: Copy files to your ESPHome directory

```bash
# If using Home Assistant with ESPHome add-on:
cd /config/esphome/

# Copy the entire components directory
cp -r pace_bms_sniffer_hexdump/components ./

# Copy the YAML file
cp pace_bms_sniffer_hexdump/pace-bms-sniffer-hexdump.yaml ./
```

Your structure should now look like:
```
/config/esphome/
├── pace-bms-sniffer-hexdump.yaml    ✓
├── secrets.yaml                      (should already exist)
└── components/
    └── pace_bms_sniffer/
        ├── __init__.py               ✓
        ├── pace_bms_sniffer.h        ✓
        └── pace_bms_sniffer.cpp      ✓
```

### Step 2: Configure your secrets.yaml

Edit `/config/esphome/secrets.yaml` and ensure it has:

```yaml
wifi_ssid: "YOUR_WIFI_NAME"
wifi_password: "YOUR_WIFI_PASSWORD"
api_encryption_key: "YOUR_ENCRYPTION_KEY"
```

### Step 3: Upload to ESP32

```bash
# From ESPHome dashboard: click "Install"
# OR from command line:
esphome run pace-bms-sniffer-hexdump.yaml
```

---

## 🔌 Hardware Wiring

**ESP32 RS485 Board → Battery Daisy Chain**

```
Battery RJ45 (Inter-battery port)     RS485 Module    ESP32
Pin 7 (White/Brown) = A+        →     A+         →    (no connection)
Pin 8 (Brown)       = B-        →     B-         →    (no connection)
                                      RO          →    GPIO16 (RX pin)
                                      DI          →    (NOT CONNECTED!)
                                      3.3V        →    3.3V
                                      GND         →    GND
```

**⚠️ CRITICAL:**
- Connect to pins 7 & 8 (inter-battery communication), NOT pins 1 & 2
- Do NOT connect TX/DI - passive listening only!
- Double-check polarity: A+ to A+, B- to B-

---

## 📺 View the Logs

### Option A: ESPHome Dashboard
1. Go to your ESPHome dashboard
2. Click "Logs" on the pace-bms-sniffer-hexdump device
3. You'll see hex dumps of all RS485 frames

### Option B: Home Assistant Log Viewer
1. Go to Settings → System → Logs
2. Select "pace-bms-sniffer-hexdump"

### Option C: Command Line
```bash
esphome logs pace-bms-sniffer-hexdump.yaml
```

---

## ✅ What You Should See

Within a few seconds, you should see:

```
[INFO] PACE BMS Sniffer - HEX DUMP MODE
[INFO] Protocol: Version 25
[INFO] Mode: PASSIVE LISTENING (RX ONLY)
[INFO] ========================================
[INFO] [RESP] Pack: 0x01 | Cmd: 0x46 | Len: 298 bytes
[INFO] HEX: 7E 32 35 30 31 34 36 30 30 31 30 39 36 ...
[INFO] Cell Voltages:
[INFO]   Cell  1: 3296 mV (3.296 V) [Hex: 0CE0]
...
```

If you see this, **SUCCESS!** 🎉

---

## 🆘 Not Working?

### No frames appearing?
- Check wiring polarity (A+ and B-)
- Verify you're on the INTER-BATTERY port (pins 7&8)
- Check baud rate is 9600
- Ensure batteries are actually powered on and communicating

### "Not protocol v25" warnings?
- You may be seeing other protocols on the bus
- This is normal if there are multiple devices
- Look for frames that start with "7E 32 35"

### ESP32 keeps rebooting?
- Check power supply (5V 2A minimum)
- Check for wiring shorts

---

## 📤 Next Steps

Once you have logs with hex dumps:

1. **Capture logs** for all 8 battery packs
2. **Compare values** against your ground truth battery data
3. **Share with me:**
   - Full hex dump for at least one frame from each pack
   - Your actual battery readings (SOC, voltage, current, etc.)
   - Any patterns or issues you notice

Then we move to **Phase 2**: Create proper Home Assistant sensors! 🚀

---

## 📖 Full Documentation

For detailed information, troubleshooting, and technical details, see:
- **README.md** - Complete documentation

---

## Need Help?

If something isn't working:
1. Read the troubleshooting section in README.md
2. Capture full logs (30+ seconds)
3. Share logs + wiring photos + battery model info

---

**Remember:** This is Phase 1 (verification). We're not creating sensors yet - just confirming we can read and parse the data correctly!
