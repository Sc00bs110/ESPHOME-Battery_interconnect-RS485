# QUICK START - PACE BMS Sniffer v2.0

## ⚡ 3-Step Installation

### Step 1: Extract Files
```bash
unzip pace_bms_sniffer_v2_PRODUCTION.zip
cd pace_bms_sniffer_v2_PRODUCTION
```

### Step 2: Copy to ESPHome
```bash
# Copy component files
cp -r components /config/esphome/

# Copy YAML config
cp pace-bms-sniffer-v2.yaml /config/esphome/
```

### Step 3: Upload
```bash
esphome run /config/esphome/pace-bms-sniffer-v2.yaml
```

Or use ESPHome dashboard and click "Install".

---

## 🔌 Hardware Setup

**Connect ESP32 RS485 to Battery Daisy Chain:**

```
Battery RJ45 Pin 7 (A+) → RS485 A+
Battery RJ45 Pin 8 (B-) → RS485 B-
RS485 RO → ESP32 GPIO16
RS485 DI → NOT CONNECTED (RX only!)
```

---

## ✅ What You'll See

```
[INFO] ╔═════════════════════════════════════════╗
[INFO] ║  PACK 2 - COMPLETE DATA DECODE          ║
[INFO] ╚═════════════════════════════════════════╝
[INFO] Cell Voltages:
[INFO]   Cell  1: 3.305 V
[INFO]   ...
[INFO]   Cell 16: 3.304 V
[INFO] Temperatures:
[INFO]   Battery 1: 25.5 °C
[INFO]   MOSFET: 25.7 °C
[INFO]   Environment: 27.1 °C
[INFO] Pack Data:
[INFO]   Current: 1.08 A
[INFO]   Voltage: 52.96 V
[INFO]   SOC: 52%
[INFO]   SOH: 100%
[INFO]   Remaining: 58.95 Ah
[INFO]   Full Capacity: 113.13 Ah
[INFO]   Cycles: 125
[INFO] Statistics:
[INFO]   Cell Delta: 0.002 V (balance: EXCELLENT)
[INFO]   Power: 57.20 W (Charging)
```

---

## 📚 Full Documentation

- **README.md** - Complete documentation
- **CHANGES_v2.0.md** - What's new in v2.0

---

## 🎯 Success Checklist

After installation:

✅ Cell voltages 3.0-3.6V  
✅ Temperatures 20-35°C  
✅ Pack voltage = sum of cells (±0.2V)  
✅ SOC matches battery display  
✅ Cell delta < 0.050V  

If all checks pass: **SUCCESS!** 🎉

---

## 🆘 Problems?

1. Check wiring (A+ and B- polarity)
2. Verify connection to inter-battery port (pins 7&8)
3. Check logs at INFO level
4. See README.md troubleshooting section

---

## 🚀 What's Working

**v2.0 Production - ALL Fields Decoded:**

✅ 16 Cell Voltages  
✅ 6 Temperatures  
✅ Pack Voltage  
✅ Current  
✅ SOC (State of Charge)  
✅ SOH (State of Health)  
✅ Remaining/Full/Design Capacity  
✅ Cycles  
✅ Cell Balance Statistics  
✅ Power Calculation  

**Ready for Phase 2: Home Assistant Integration!**

---

**Need help? See README.md for full documentation!**
