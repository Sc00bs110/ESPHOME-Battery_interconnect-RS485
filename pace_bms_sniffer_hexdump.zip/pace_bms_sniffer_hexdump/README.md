# PACE BMS Sniffer - Hex Dump Mode
## Phase 1: Verify RS485 Data Parsing

This is the first phase of your PACE BMS integration. The goal is to capture raw RS485 frames from the inter-battery daisy chain and verify the parsing is correct.

---

## 📁 File Structure

Your ESPHome project should have this structure:

```
/config/esphome/
├── pace-bms-sniffer-hexdump.yaml       # Main config file
├── secrets.yaml                         # Your WiFi credentials
└── components/
    └── pace_bms_sniffer/
        ├── __init__.py                  # Component registration
        ├── pace_bms_sniffer.h           # Header file
        └── pace_bms_sniffer.cpp         # Implementation
```

---

## 🔧 Installation Steps

### 1. Create the directory structure
```bash
mkdir -p /config/esphome/components/pace_bms_sniffer
```

### 2. Copy the files
- Place `pace-bms-sniffer-hexdump.yaml` in `/config/esphome/`
- Place `__init__.py`, `pace_bms_sniffer.h`, and `pace_bms_sniffer.cpp` in `/config/esphome/components/pace_bms_sniffer/`

### 3. Ensure your secrets.yaml exists
```yaml
# /config/esphome/secrets.yaml
wifi_ssid: "YOUR_WIFI_SSID"
wifi_password: "YOUR_WIFI_PASSWORD"
api_encryption_key: "YOUR_API_KEY"
```

### 4. Hardware Connections

**CRITICAL: RX ONLY MODE - NO TRANSMIT!**

Connect your ESP32 RS485 board to the inter-battery daisy chain:

```
Battery Daisy Chain (RJ45 pins 7&8)  →  RS485 Module  →  ESP32
          A+ (pin 7, white/brown)    →     A+         →  (no connection)
          B- (pin 8, brown)          →     B-         →  (no connection)
                                     
RS485 Module  →  ESP32
     RO       →  GPIO16 (RX)
     DI       →  (NOT CONNECTED - passive mode)
     3.3V     →  3.3V
     GND      →  GND
```

**Important Notes:**
- Do NOT connect the TX pin (DI on RS485 module)
- Connect to the INTER-BATTERY ports (typically pins 7&8), not the user communication port
- Your ESP32 will only LISTEN, never transmit

---

## 🚀 Compilation and Upload

### Option A: ESPHome Dashboard
1. Open ESPHome dashboard
2. Click "Install" on the pace-bms-sniffer-hexdump device
3. Choose "Wireless" or "Plug into this computer" for first upload

### Option B: Command Line
```bash
esphome run pace-bms-sniffer-hexdump.yaml
```

---

## 📊 What You'll See in the Logs

Once running, you'll see detailed hex dumps of every frame:

### Example Output:
```
[12:34:56][I][pace_bms_sniffer:xxx]: ========================================
[12:34:56][I][pace_bms_sniffer:xxx]: [RESP] Pack: 0x02 | Cmd: 0x46 | Len: 298 bytes
[12:34:56][I][pace_bms_sniffer:xxx]: ----------------------------------------
[12:34:56][I][pace_bms_sniffer:xxx]: HEX: 7E 32 35 30 32 34 36 30 30 31 30 39 36 ...
[12:34:56][I][pace_bms_sniffer:xxx]: ASCII: ~250246001096...
[12:34:56][I][pace_bms_sniffer:xxx]: ========================================
[12:34:56][I][pace_bms_sniffer:xxx]: ┌─────────────────────────────────────────┐
[12:34:56][I][pace_bms_sniffer:xxx]: │  DECODING PACK 2 ANALOG DATA           │
[12:34:56][I][pace_bms_sniffer:xxx]: └─────────────────────────────────────────┘
[12:34:56][I][pace_bms_sniffer:xxx]: Cell Voltages:
[12:34:56][I][pace_bms_sniffer:xxx]:   Cell  1: 3296 mV (3.296 V) [Hex: 0CE0]
[12:34:56][I][pace_bms_sniffer:xxx]:   Cell  2: 3296 mV (3.296 V) [Hex: 0CE0]
[12:34:56][I][pace_bms_sniffer:xxx]:   ...
```

---

## ✅ Verification Steps

### 1. Check Cell Voltages
Compare the decoded cell voltages against your "ground truth" values from the images you provided:

**Pack 2 Expected (from your image):**
- Cell 1: 3.296 V
- Cell 2: 3.297 V
- Cell 3: 3.297 V
- etc.

**If they don't match:**
- The hex values will help us identify the correct byte positions
- Cell voltages are in millivolts, divided by 1000

### 2. Check Temperatures
Expected values from your images:

**Pack 2 Expected:**
- Battery Temp 1: 24.0°C
- Battery Temp 2: 24.3°C
- Battery Temp 3: 23.7°C
- Battery Temp 4: 23.9°C
- MOSFET Temp: 24.7°C
- Environment: 26.1°C

### 3. Look for Pack Voltage
Your images show pack voltages around 52.44-52.51V. The sniffer will attempt to decode this and show the hex values so we can verify the position.

### 4. Analyze the "Next 40 chars" Output
The log will show the next 40 characters after the cell voltages and temperatures. This section contains:
- Pack voltage
- Current (should be negative, e.g., -4.12A)
- SOC (36-51%)
- Remaining capacity (37-77 Ah)
- Full capacity (100-151 Ah)
- Cycles (40-129)
- SOH (100%)

---

## 🔍 What to Share With Me

Once you have logs, please share:

1. **Full log output** for at least one complete frame from each battery (if possible)
2. **The hex dump** - especially the "HEX:" and "ASCII:" lines
3. **Your ground truth values** - so I can compare against the decoded data
4. **Any patterns you notice** - e.g., "Cell voltages look correct but temperatures are way off"

Example of what to share:
```
Pack 2:
- HEX line from log: 7E 32 35 30 32 34 36 30 30 31 30 39 36 ...
- Actual Cell 1 voltage: 3.297V
- Decoded Cell 1 voltage: 3.296V ✓ (close enough)
- Actual Current: -3.99A
- Decoded Current: ??? (not decoded yet)
```

---

## 🎯 Next Steps (Phase 2)

Once we verify the parsing is correct:
1. Create proper sensor definitions for all 8 packs
2. Implement rate limiting to avoid excessive data
3. Add all sensors to Home Assistant
4. Implement proper error handling
5. Add battery status indicators (charging/discharging)

---

## ⚠️ Troubleshooting

### No frames appearing in logs
- Check RS485 wiring (A+/B- correct polarity)
- Verify you're connected to the inter-battery ports (pins 7&8), not the user port
- Check that batteries are actually communicating (look at battery display)
- Ensure baud rate is 9600 (default for PACE BMS)

### Getting "Not protocol v25" warnings
- You may be seeing other traffic on the bus
- Protocol v25 frames start with: 7E 32 35 (~ 2 5)
- If you see different protocols, let me know

### ESP32 keeps rebooting
- Check power supply is adequate
- Reduce logging level to WARNING temporarily
- Check for shorts in wiring

### Frames look corrupted
- Check RS485 termination (may need 120Ω resistor)
- Verify ground connection
- Try shorter cables if possible

---

## 📝 Additional Notes

**Frame Format Reference:**
```
~25[ADDR][CMD][DATA][CHECKSUM]\r

Where:
- ~ (0x7E): Start of frame
- 25: Protocol version (ASCII "25")
- ADDR: 2 hex digits (01-08 for your batteries)
- CMD: 2 hex digits (46 = read analog data)
- DATA: Variable length hex data
- CHECKSUM: 4 hex digits
- \r (0x0D): End of frame (carriage return)
```

**Inter-Battery Communication:**
- Master battery (typically address 1) polls slaves
- Each battery responds with its data
- You should see traffic for multiple addresses

**Passive Listening:**
- Your ESP32 will NEVER transmit
- It only observes the conversation between batteries
- This cannot interfere with battery operation

---

## 📞 Support

If you encounter issues:
1. Check the troubleshooting section above
2. Capture full logs (at least 30 seconds worth)
3. Share the logs along with your battery model information
4. Include photos of your wiring if possible

Good luck! 🚀
