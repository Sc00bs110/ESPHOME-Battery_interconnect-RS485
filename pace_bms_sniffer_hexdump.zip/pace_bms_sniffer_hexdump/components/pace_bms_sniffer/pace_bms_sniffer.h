#pragma once

#include "esphome/core/component.h"
#include "esphome/components/uart/uart.h"
#include "esphome/components/sensor/sensor.h"
#include <vector>

namespace esphome {
namespace pace_bms_sniffer {

static const uint8_t FRAME_START = 0x7E;  // '~'
static const uint8_t FRAME_END = 0x0D;    // '\r'
static const size_t MAX_FRAME_SIZE = 512;
static const uint8_t NUM_PACKS = 8;
static const uint8_t NUM_CELLS = 16;
static const uint8_t NUM_TEMPS = 6;

struct PackData {
  float cell_voltages[NUM_CELLS];
  float temperatures[NUM_TEMPS];
  float current;
  float voltage;
  float soc;
  float soh;
  float remaining_cap;
  float full_cap;
  float design_cap;
  uint16_t cycles;
  
  // Calculated values
  float min_cell_v;
  float max_cell_v;
  float avg_cell_v;
  float delta_cell_v;
  
  bool valid;
  uint32_t last_update;
  
  PackData() : current(0), voltage(0), soc(0), soh(100), 
               remaining_cap(0), full_cap(0), design_cap(0), cycles(0),
               min_cell_v(0), max_cell_v(0), avg_cell_v(0), delta_cell_v(0),
               valid(false), last_update(0) {
    for (uint8_t i = 0; i < NUM_CELLS; i++) cell_voltages[i] = 0;
    for (uint8_t i = 0; i < NUM_TEMPS; i++) temperatures[i] = 0;
  }
};

struct PackSensors {
  sensor::Sensor *current{nullptr};
  sensor::Sensor *voltage{nullptr};
  sensor::Sensor *soc{nullptr};
  sensor::Sensor *soh{nullptr};
  sensor::Sensor *remaining_cap{nullptr};
  sensor::Sensor *full_cap{nullptr};
  sensor::Sensor *design_cap{nullptr};
  sensor::Sensor *cycles{nullptr};
  sensor::Sensor *temps[NUM_TEMPS]{nullptr};
  sensor::Sensor *cell_voltages[NUM_CELLS]{nullptr};
  sensor::Sensor *min_cell{nullptr};
  sensor::Sensor *max_cell{nullptr};
  sensor::Sensor *avg_cell{nullptr};
  sensor::Sensor *delta_cell{nullptr};
};

class PaceBMSSniffer : public Component, public uart::UARTDevice {
 public:
  void setup() override;
  void loop() override;
  void dump_config() override;
  float get_setup_priority() const override { return setup_priority::DATA; }
  
  // Setter methods for sensors (for future use)
  void set_current_sensor(uint8_t pack_idx, sensor::Sensor *sensor) {
    if (pack_idx < NUM_PACKS) pack_sensors_[pack_idx].current = sensor;
  }
  void set_voltage_sensor(uint8_t pack_idx, sensor::Sensor *sensor) {
    if (pack_idx < NUM_PACKS) pack_sensors_[pack_idx].voltage = sensor;
  }
  void set_soc_sensor(uint8_t pack_idx, sensor::Sensor *sensor) {
    if (pack_idx < NUM_PACKS) pack_sensors_[pack_idx].soc = sensor;
  }
  
 protected:
  std::vector<uint8_t> rx_buffer_;
  PackData pack_data_[NUM_PACKS];
  PackSensors pack_sensors_[NUM_PACKS];
  
  void process_frame(const std::vector<uint8_t> &frame);
  void print_hex_dump(const std::vector<uint8_t> &frame);
  bool decode_analog_data(const std::vector<uint8_t> &frame, uint8_t pack_addr);
  void calculate_pack_stats(uint8_t pack_idx);
  void publish_pack_data(uint8_t pack_idx);
  
  uint8_t hex_char_to_byte(char c);
  uint16_t parse_hex_word(const uint8_t *data);
  uint32_t parse_hex_dword(const uint8_t *data);
};

}  // namespace pace_bms_sniffer
}  // namespace esphome
